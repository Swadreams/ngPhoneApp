'use strict';

describe('myApp.view1 module', function() {

  beforeEach(module('myApp.view1'));

  describe('view1 controller', function(){
        var $scope;
        beforeEach(inject(function($rootScope, $controller){
            $scope = $rootScope.$new();
            $controller('View1Ctrl',{$scope: $scope});
        }));

    // it('should execute ....', inject(function($controller) {
    //   //spec body
    //   var view1Ctrl = $controller('View1Ctrl',{});
    //   expect(view1Ctrl).toBeDefined();
    // }));

    it('Test should fail',function(){
      expect(true).toBe(true);
    });

    it('should set the default value of employee',function(){
      expect($scope.employee).toBe("Ben");
    });

  });
});