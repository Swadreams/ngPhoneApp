'use strict';

angular.module('myApp.pshop', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/pshop', {
      templateUrl: 'shop/index.html',
   // controller: 'PhoneListController'
  });
}])

// // Define the `PhoneListController` controller on the `phonecatApp` module
// .controller('PhoneListController', function PhoneListController($scope) {
//   $scope.phones = [
//     {
//       name: 'Nexus S',
//       snippet: 'Fast just got faster with Nexus S.'
//     }, {
//       name: 'Motorola XOOM™ with Wi-Fi',
//       snippet: 'The Next, Next Generation tablet.'
//     }, {
//       name: 'MOTOROLA XOOM™',
//       snippet: 'The Next, Next Generation tablet.'
//     }
//   ];
// });

.component('phoneList', {
    // template:
    //     '<ul>' +
    //       '<li ng-repeat="phone in $ctrl.phones">' +
    //         '<span>{{phone.name}}</span>' +
    //         '<p>{{phone.snippet}}</p>' +
    //       '</li>' +
    //     '</ul>',
    templateUrl: 'shop/phone-list.template.html',
    controller: function PhoneListController($http) {
      var self = this;
      self.orderProp = 'age';

      $http.get('shop/phones/phones.json').then(function(response){
        self.phones = response.data;
      });
    }
  });